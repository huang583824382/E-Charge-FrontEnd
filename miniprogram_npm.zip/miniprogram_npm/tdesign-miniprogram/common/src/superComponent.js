export class SuperComponent {
    constructor() {
        this.app = getApp();
    }
}

//# sourceMappingURL=superComponent.js.map
