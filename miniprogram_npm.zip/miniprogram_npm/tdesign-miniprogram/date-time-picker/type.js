/* eslint-disable */
;
;
;
export {};

//# sourceMappingURL=type.js.map
