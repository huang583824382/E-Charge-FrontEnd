/* eslint-disable */
const props = {
    /** 数据源 */
    options: {
        type: Array,
        value: [],
    },
    /** 默认选中的侯选项 */
    value: {
        type: String,
        optionalTypes: [Number],
    },
};
export default props;

//# sourceMappingURL=picker-item-props.js.map
