/**
 * 该文件为脚本自动生成文件，请勿随意修改。如需修改请联系 PMC
 * updated at 2021-09-20 16:58:42
 * */
import { TdIconProps } from './type';
declare const props: TdIconProps;
export default props;
