import { TdTransitionProps } from './type';
export declare type TransitionProps = TdTransitionProps;
